<?php
global $_W, $_GPC;
$this->checkWebDo('index');
include $this->template('web/index');
