<?php
global $_W,$_GPC;

die(json_encode($_GPC));